#!/usr/bin/env bash
# usage: lh.sh <mode devtools|simulate> <runs> <label> path...   (kết quả: /tmp/lh-out/<label>/*.json + tóm tắt)
set -euo pipefail
# (đã bỏ: source /tmp/s11lh-env.sh — biến môi trường, chứa mật khẩu seed)
cd ~/Documents/TA_Agent_s108dev
export LH_ORIGIN=https://localhost:3460 NODE_TLS_REJECT_UNAUTHORIZED=0 CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
mode=$1; runs=$2; label=$3; shift 3
rm -rf /tmp/lh-out/$label .lighthouseci; mkdir -p /tmp/lh-out/$label
args=(); for u in "$@"; do args+=(--url="$LH_ORIGIN$u"); done
frontend/node_modules/.bin/lhci collect --config=benchmarks/lighthouse/lighthouserc.ep.json --numberOfRuns=$runs "${args[@]}" --settings.throttlingMethod=$mode >/tmp/lh-out/$label.log 2>&1 || { tail -5 /tmp/lh-out/$label.log; exit 1; }
cp .lighthouseci/lhr-*.json /tmp/lh-out/$label/
node /tmp/lh-sum.mjs /tmp/lh-out/$label
