import { readdirSync, readFileSync } from "node:fs";
const dir = process.argv[2]; const by = {};
const med = (a) => { const s = [...a].sort((x, y) => x - y); return s[Math.floor(s.length / 2)]; };
for (const f of readdirSync(dir).filter((x) => x.endsWith(".json"))) {
  const l = JSON.parse(readFileSync(`${dir}/${f}`, "utf8")); const a = l.audits;
  const el = a["largest-contentful-paint-element"]?.details?.items?.[0]?.items?.[0]?.node?.snippet?.slice(0, 70) ?? "";
  (by[new URL(l.finalDisplayedUrl ?? l.requestedUrl).pathname] ??= []).push({ lcp: a["largest-contentful-paint"].numericValue, fcp: a["first-contentful-paint"].numericValue, tbt: a["total-blocking-time"].numericValue, el });
}
for (const [r, xs] of Object.entries(by)) console.log(r.padEnd(40).slice(0,40), "LCP", Math.round(med(xs.map((x) => x.lcp))), "runs", xs.map((x) => Math.round(x.lcp)).join("/"), "FCP", Math.round(med(xs.map((x) => x.fcp))), "TBT", Math.round(med(xs.map((x) => x.tbt))), "|", xs[0].el);
