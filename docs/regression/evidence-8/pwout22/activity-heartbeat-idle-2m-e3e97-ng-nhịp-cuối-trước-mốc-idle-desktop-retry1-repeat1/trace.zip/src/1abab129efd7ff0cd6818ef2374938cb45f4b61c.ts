import { BASE_URL } from "./env";
import { doc as docRow, libDetail, libItem, stats as docStats } from "./doc-fixtures";
import { exam as calExam, item as calItem, session as calSession } from "./cal-fixtures";
import { gridBody as attGrid, sessionRow as attSession } from "./att-fixtures";
import { TID as THREAD_ID, row as threadRow, view as threadView } from "./thread-fixtures";
import type { BrowserContext, Page, Route } from "@playwright/test";

export type DemoRole = "student" | "ta" | "teacher" | "admin";

// Tài khoản seed (US-P2-12) ↔ người mock: màn mô phỏng lấy NGƯỜI từ email của phiên (src/mock/identity.ts). Không còn cookie phiên mô phỏng (AC10).
const SEED_EMAIL: Record<string, string> = {
  "sv-1": "sv.gioi@edupilot.local", "sv-2": "sv.kha@edupilot.local", "sv-3": "sv.nguyco@edupilot.local", "sv-4": "sv.moi@edupilot.local",
  ta: "ta@edupilot.local", teacher: "teacher@edupilot.local", admin: "admin@edupilot.local",
};
// Lớp THẬT tương ứng lớp mô phỏng (class_code 761987 ↔ int1006-1, 761988 ↔ int1006-2); mã sinh viên mô phỏng → lớp họ học.
const COURSE_ID = { "761987": "00000000-0000-7000-8000-00000000c001", "761988": "00000000-0000-7000-8000-00000000c002" } as const;
const STUDENT_CLASSES: Record<string, Array<keyof typeof COURSE_ID>> = { "sv-1": ["761987", "761988"], "sv-2": ["761987"], "sv-3": ["761987"], "sv-4": [] };

const mineItem = (code: keyof typeof COURSE_ID, role: "TEACHER" | "TA" | "STUDENT") => ({
  course: { id: COURSE_ID[code], class_code: code, subject_code: "INT1006", name: "An ninh mạng", semester: "2026-2027-HK1", status: "ACTIVE" },
  role_in_course: role,
  enrollment_status: "ACTIVE",
});

/** Kết nối `/events` của chuông (US-P4-02): mặc định "mở rồi im" để trang có phiên không chạm máy chủ giả dùng chung (`api-server.mjs`) làm sai số đếm của test lớp dữ liệu chạy song song. */
export const idleEvents = (cors: Record<string, string>) => ({ status: 200, headers: { ...cors, "Content-Type": "text/event-stream", "Cache-Control": "no-cache" }, body: 'retry: 3000\n\nevent: ready\ndata: {"conn_id":"c"}\n\n' });

/**
 * Đăng nhập GIẢ bằng JWT cho màn mô phỏng (thay bộ đổi vai bằng cookie đã bị xoá — US-P2-12 AC10): `POST /auth/refresh` trả phiên của
 * tài khoản seed tương ứng vai / người, `GET /me/courses` trả lớp thật tương ứng. Gateway không chạy: mọi lời gọi khác bị bỏ qua.
 */
export async function asDemo(context: BrowserContext, role: DemoRole, opts: { person?: string; expIn?: number } = {}) {
  await context.addInitScript(() => localStorage.setItem("ep_returning", "1")); // máy đã từng đăng nhập: `/` vẽ khung "Hôm nay" thay vì trang giới thiệu (OPS-VPS landing)
  const person = role === "student" ? (opts.person ?? "sv-2") : role;
  const email = SEED_EMAIL[person];
  const jwtRole: JwtRole = role === "student" ? "STUDENT" : (role.toUpperCase() as JwtRole);
  const cors = { "Access-Control-Allow-Origin": BASE_URL, "Access-Control-Allow-Credentials": "true", Vary: "Origin" };
  const json = (body: unknown) => ({ status: 200, contentType: "application/json", headers: cors, body: JSON.stringify(body) });
  await context.route("**/api/v1/auth/refresh", async (r) => r.fulfill(json(sessionBody(jwtRole, { email, expIn: opts.expIn, now: await pageNowSec(r) }))));
  await context.route("**/api/v1/auth/logout", (r) => r.fulfill({ status: 204, headers: cors }));
  const items =
    role === "student" ? (STUDENT_CLASSES[person] ?? []).map((c) => mineItem(c, "STUDENT"))
    : role === "ta" ? [mineItem("761987", "TA")]
    : role === "teacher" ? [mineItem("761987", "TEACHER"), mineItem("761988", "TEACHER")]
    : [];
  await context.route("**/api/v1/me/courses**", (r) => r.fulfill(json({ items, next_cursor: null })));
  const today = role === "student" ? { no_course: items.length === 0, email_verified: true, recommended: null, timeline: [], continue: [] }
    : role === "admin" ? { count: 0, actions: [] }
    : { count: 0, actions: [], attention: [], upcoming: [] };
  await context.route("**/api/v1/me/today**", (r) => r.fulfill(json(today)));
  await context.route("**/api/v1/courses/*/today**", (r) => r.fulfill(json(today)));
  // chat riêng THẬT (US-P3-05): phiên đăng nhập thật có lớp → /chat gọi API; mặc định chưa có phiên, không bị khoá giờ thi
  await context.route("**/api/v1/chat/sessions?**", (r) => r.fulfill(json({ items: [], next_cursor: null })));
  await context.route("**/api/v1/me/exam-lock", (r) => r.fulfill(json({ locked: false })));
  // Threads THẬT (US-P3-06): danh sách một thread + chi tiết `TID`; các lời gọi khác (POST…) do từng spec tự giả (`threadApi`, page-level thắng)
  await context.route("**/api/v1/courses/*/threads**", (r) => {
    const u = new URL(r.request().url()).pathname;
    if (r.request().method() !== "GET") return r.fallback();
    if (u.endsWith(`/threads/${THREAD_ID}`)) return r.fulfill(json(threadView()));
    if (u.endsWith("/similar")) return r.fulfill(json({ items: [] }));
    return r.fulfill(json({ items: [threadRow()], next_cursor: null }));
  });
  // Tài liệu / thư viện THẬT (US-P8-02): một tài liệu mặc định; spec cần hành vi khác thì tự giả bằng `docApi` (page-level thắng).
  await context.route("**/api/v1/courses/*/documents**", (r) => {
    const u = new URL(r.request().url()).pathname;
    if (r.request().method() !== "GET") return r.fallback();
    if (u.endsWith("/stats")) return r.fulfill(json(docStats()));
    if (u.endsWith("/chunks")) return r.fulfill(json({ items: [], next_cursor: null }));
    return r.fulfill(json({ items: [docRow()], next_cursor: null }));
  });
  await context.route("**/api/v1/courses/*/library**", (r) => {
    const u = new URL(r.request().url()).pathname;
    if (r.request().method() !== "GET") return r.fallback();
    if (u.endsWith("/download")) return r.fulfill(json({ url: "http://localhost:9/f.pdf" }));
    if (/\/library\/[^/]+$/.test(u)) return r.fulfill(json(libDetail()));
    return r.fulfill(json({ items: [libItem()], next_cursor: null }));
  });
  // Lịch THẬT (US-P8-03): vài dòng mặc định; spec cần hành vi khác thì tự giả bằng `calApi` (page-level thắng).
  await context.route("**/api/v1/courses/*/calendar**", (r) => (r.request().method() === "GET" ? r.fulfill(json({ items: [calExam(), calItem(), calSession()], next_cursor: null })) : r.fallback()));
  // Điểm danh THẬT (US-P5-02): hai buổi và một lưới mặc định; spec cần hành vi khác thì tự giả bằng `attApi` (page-level thắng).
  await context.route("**/api/v1/courses/*/sessions**", (r) => {
    const u = new URL(r.request().url()).pathname;
    if (r.request().method() !== "GET") return r.fallback();
    if (u.endsWith("/attendance")) return r.fulfill(json(attGrid(2)));
    return r.fulfill(json({ items: [attSession(2), attSession(1)], next_cursor: null }));
  });
  // Hộp thư hỗ trợ THẬT (US-P4-03): một ticket mặc định; spec cần hành vi khác thì tự giả bằng `inboxApi` (page-level thắng).
  const tk = { id: "00000000-0000-7000-8000-0000000000f7", status: "OPEN", kind: "QUESTION", student: { id: "00000000-0000-7000-8000-0000000000a1", full_name: "Sinh Viên Thử" }, question_preview: "Điểm chuyên cần tính thế nào?", age_minutes: 95, claimed_by: null, sla_stage: 0, course: { id: COURSE_ID["761987"], class_code: "761987" } };
  await context.route("**/api/v1/me/tickets**", (r) => r.fulfill(json({ items: [tk], next_cursor: null })));
  await context.route("**/api/v1/courses/*/tickets**", (r) => {
    if (r.request().method() !== "GET") return r.fallback();
    if (new URL(r.request().url()).pathname.endsWith("/tickets")) return r.fulfill(json({ items: [tk], next_cursor: null }));
    return r.fulfill(json({
      ticket: { ...tk, answered_by: null, reopened_count: 0, save_as_knowledge: false, version: 1, created_at: "2026-10-11T02:00:00Z" },
      question: { id: "q1", content: "Điểm chuyên cần tính thế nào?", created_at: "2026-10-11T02:00:00Z" },
      ai_answer: { id: "a1", content: "Mình chưa tìm thấy quy định này.", created_at: "2026-10-11T02:00:01Z", confidence: "0.42" },
      transcript: [],
    }));
  });
  await context.route("**/api/v1/admin/observability/failed-mail**", (r) => r.fulfill(json({ items: [], next_cursor: null }))); // US-P4-04: mặc định không có thư lỗi
  await context.route("**/api/v1/notifications**", (r) => r.fulfill(json({ items: [], next_cursor: null, unread_count: 0 })));
  await context.route("**/api/v1/events", (r) => r.fulfill(idleEvents(cors)));
}

export type JwtRole = "ADMIN" | "TEACHER" | "TA" | "STUDENT";

/** JWT giả (chữ ký không kiểm ở client): chỉ để frontend giải mã vai / email / hạn. */
/**
 * Giờ của TRANG (giây): đồng hồ giả nếu spec đã đặt (`page.clock.*`), nếu không là giờ thật. JWT giả PHẢI ký theo đây: ký bằng giờ thật của Node thì
 * spec đặt đồng hồ cố định (trước hay sau giờ thật) được token "hết hạn" hay "còn hạn" tuỳ ngày chạy (BUG-S8-01, #17).
 */
export async function pageNowSec(route: Route): Promise<number> {
  try {
    return Math.floor((await route.request().frame().evaluate(() => Date.now())) / 1000);
  } catch {
    return Math.floor(Date.now() / 1000); // không có khung (service worker / đang chuyển trang)
  }
}

export function makeJwt(role: JwtRole | string, opts: { email?: string; expIn?: number; sid?: string; now?: number } = {}) {
  const now = opts.now ?? Math.floor(Date.now() / 1000);
  const b64 = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");
  return `${b64({ alg: "HS256", typ: "JWT" })}.${b64({
    sub: "00000000-0000-7000-8000-0000000000a0", role, email: opts.email ?? "admin@ptit.edu.vn", sid: opts.sid ?? "00000000-0000-7000-8000-0000000000b0",
    iat: now, exp: now + (opts.expIn ?? 900),
  })}.c2ln`;
}

export const sessionBody = (role: JwtRole, opts: { email?: string; fullName?: string; expIn?: number; now?: number } = {}) => {
  const email = opts.email ?? `${role.toLowerCase()}@ptit.edu.vn`;
  return {
    access_token: makeJwt(role, { email, expIn: opts.expIn, now: opts.now }), token_type: "Bearer", expires_in: 900,
    user: { id: "00000000-0000-7000-8000-0000000000a0", email, full_name: opts.fullName ?? "Người Thử", role, status: "ACTIVE", email_verified: true },
  };
};

/**
 * Giả lập phiên đăng nhập thật cho MỘT trang: `POST /auth/refresh` (lúc tải trang) trả về phiên của `role`; `POST /auth/logout` → 204.
 * Không dùng máy chủ giả dùng chung nên không cần khoá. Trả bộ đếm lời gọi refresh để test khẳng định.
 */
export async function asJwt(page: Page, role: JwtRole, opts: { email?: string; fullName?: string; expIn?: number } = {}) {
  const calls = { refresh: 0, logout: 0 };
  const cors = { "Access-Control-Allow-Origin": BASE_URL, "Access-Control-Allow-Credentials": "true", Vary: "Origin" };
  await page.addInitScript(() => localStorage.setItem("ep_returning", "1")); // US-UX91-21: `/` chỉ làm mới phiên khi máy đã từng đăng nhập
  await page.route("**/api/v1/auth/refresh", async (route) => {
    calls.refresh++;
    return route.fulfill({ status: 200, contentType: "application/json", headers: cors, body: JSON.stringify(sessionBody(role, { ...opts, now: await pageNowSec(route) })) });
  });
  await page.route("**/api/v1/auth/logout", (route) => {
    calls.logout++;
    return route.fulfill({ status: 204, headers: cors });
  });
  await page.route("**/api/v1/events", (route) => route.fulfill(idleEvents(cors)));
  return calls;
}
